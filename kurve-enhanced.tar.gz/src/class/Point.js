class Point {
  /**
   * Point class for coordinates
   * @param {number} x
   * @param {number} y
   */
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
}

module.exports = Point;
